<?php
    $firstName = $_REQUEST['firstName'];

    echo("First: " . $firstName);

    ?>

